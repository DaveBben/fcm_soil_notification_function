# Google Cloud Function for Soil Sensors
This cloud function sends a push notification to the *plants* topic when the the moisture value passes a certain threshold or the battery level is too low. This is a bare bones function designed specifically for my needs using the bare minimum of code and no testing.

As part of this project, I have Arduino soil sensors that push data to a Raspberry Pi gateway. The Raspberry Pi gateway uploads that data to Google Firebase. Ths functions reads that documents and pushes a notification using FCM to my custom designed android app.